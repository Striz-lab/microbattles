from tkinter import *
import matplotlib
import math
from PIL import ImageTk, Image
from random import randint
from time import sleep

root = Tk()
root.geometry('667x500')
canvas = Canvas(root, width=700, height=700)
canvas.pack()
pilImage = None
pilImage1 = None
image = None
image1 = None
pilImage2 = None
image2 = None
player = None
calboy2 = None
cactus_pil = []
cactus_im = []
cactus_list = []
bullet_pil = None
bullet_im = None
num_of_cactuses = randint(7, 12)
bullet1 = None
bullet2 = None


class Bullet:
    def __init__(self, x=0, y=0, vx=0, vy=0, str=None):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.r = 2
        self.pilIm = Image.open(str)
        self.Im = ImageTk.PhotoImage(self.pilIm)
        self.flag = False
        self.id = None
        self.id = canvas.create_image(self.x, self.y, image=self.Im)

    def set_coords(self):
        canvas.coords(self.id, self.x, self.y)

    def move(self):
        self.x += self.vx
        self.y += self.vy
        if self.y > 323 or self.y < 50:
            self.vy = -self.vy
            canvas.delete(self.id)
            a = math.asin(self.x / math.sqrt(self.x ** 2 + self.y ** 2))
            self.pilIm = rotate(self.pilIm, 2 * a)
            self.Im = ImageTk.PhotoImage(self.pilIm)
            self.id = canvas.create_image(self.x, self.y, image=self.Im)

        self.set_coords()
        root.after(10, self.move)


class Cowboy:
    def __init__(self, x=0, y=0, v=0, str=None):
        self.lives = 5
        self.x = x
        self.y = y
        self.v = v
        self.r = 22
        self.t = 40
        self.fire_flag = False
        self.bullet = None
        self.str = str
        self.num_of_bullets = 1
        self.pilIm = Image.open(self.str)
        self.Im = ImageTk.PhotoImage(self.pilIm)
        self.id = canvas.create_image(self.x, self.y, image=self.Im)

    def fire(self, event):
        if self.num_of_bullets == 1:
            if self.x < 250:
                self.bullet = Bullet(self.x, self.y, 5, 0, "пуля2.png")
                self.str = 'калбой1.png'
            if self.x > 250:
                self.bullet = Bullet(self.x, self.y, -5, 0, "пуля1.png")
                self.str = 'калбой2.png'
            self.t = 200
            update_picture(self, self.str)
            self.v = -self.v
            self.num_of_bullets = 0
            self.bullet.move()
        else:
            self.t = 150
            self.v = -self.v

    def set_coords(self):
        canvas.coords(self.id, self.x, self.y)

    def move(self):
        if self.y > 323 or self.y < 50:
            self.v = -self.v
        self.y -= self.v
        self.set_coords()
        root.after(self.t, self.move)
        self.t = 40


class Cactus:
    def __init__(self):
        self.x = randint(200, 520)
        self.y = randint(60, 310)
        self.r = 15 #19
        self.pilIm = Image.open("кактус.png")
        self.Im = ImageTk.PhotoImage(self.pilIm)
        self.id = canvas.create_image(self.x, self.y, image=self.Im)


def cactuses_generation():
    global cactus_list, cactus_im, cactus_pil
    for i in range(num_of_cactuses):
        obj = Cactus()
        cactus_list.append(obj)
        cactus_pil.append(obj.pilIm)
        cactus_im.append(obj.Im)
    for i in range(num_of_cactuses):
        for j in range(num_of_cactuses):
            if i != j and (cactus_list[i].x - cactus_list[j].x) ** 2 + (cactus_list[i].y - cactus_list[j].y) ** 2 <= 4 * cactus_list[j].r ** 2:
                canvas.delete(cactus_list[i].id)
                del cactus_list[i]
                obj = Cactus()
                cactus_list.append(obj)
                cactus_pil.append(obj.pilIm)
                cactus_im.append(obj.Im)



def anim():
    calboy1.move()
    calboy2.move()


def update_picture(obj, str):
    canvas.delete(obj.id)
    obj.pilIm = Image.open(str)
    obj.Im = ImageTk.PhotoImage(obj.pilIm)
    obj.id = canvas.create_image(obj.x, obj.y, image=obj.Im)


def rotate(img, ang):
    out = img.rotate(- 2 * math.pi + ang)
    return out


def duel(player1, player2):
    if player1.bullet is not None:
        if (player1.bullet.x - player2.x) ** 2 <= player2.r ** 2 and (
                player1.bullet.y - player2.y) ** 2 <= player2.r ** 2:
            player2.lives -= 1
            root.after(20, update_picture(calboy2, "калкалбой2.png"))
            # root.after(100, update_picture(calboy2, "калбой2.png"))
            canvas.delete(player1.bullet.id)

            #update_picture(player2, "калбой2.png")

            # if calboy2.num_of_bullets == 0:
            #     calboy2.pilIm = Image.open("калбой2.png")
            #     calboy2.Im = ImageTk.PhotoImage(calboy2.pilIm)
            #     calboy2.id = canvas.create_image(calboy2.x, calboy2.y, image=calboy2.Im)
            # else:
            #     calboy2.pilIm = Image.open("кулбой2.png")

            #     calboy2.Im = ImageTk.PhotoImage(calboy2.pilIm)
            #     calboy2.id = canvas.create_image(calboy2.x, calboy2.y, image=calboy2.Im)
    root.after(2, lambda: duel(player1, player2))


# def cactus_collision(player, cactuses):
#     if player.bullet is not None:
#         for i in range(num_of_cactuses):
#             if (player.bullet.x - cactuses[i].x) ** 2 <= cactuses[i].r ** 2 and (
#                     player.bullet.y - cactuses[i].y) ** 2 <= cactuses[i].r ** 2:
#                 player.bullet.vx = -player.bullet.vx
#     root.after(20, lambda: cactus_collision(player, cactuses))


def cactus_collision(player):
    global cactus_list
    if player.bullet is not None:
        for i in range(num_of_cactuses):
            if (player.bullet.x - cactus_list[i].x) ** 2 <= cactus_list[i].r ** 2 and (
                    player.bullet.y - cactus_list[i].y) ** 2 <= cactus_list[i].r ** 2:
                player.bullet.x = cactus_list[i].x - cactus_list[i].r
                z = (cactus_list[i].x - player.bullet.x) * player.bullet.vy / player.bullet.vx + player.bullet.y
                if (player.bullet.y - z) != 0:
                    c = math.atan((player.bullet.x - cactus_list[i].x) / (player.bullet.y - z))
                else:
                    c = math.pi / 2
                if (player.bullet.y - cactus_list[i].y) != 0:
                    b = math.atan((player.bullet.x - cactus_list[i].x) / (player.bullet.y - cactus_list[i].y))
                else:
                    b = math.pi / 2
                a = b + c + math.pi
                player.bullet.vx = math.cos(2 * a) * player.bullet.vx - math.sin(2 * a) * player.bullet.vy
                player.bullet.vy = math.sin(2 * a) * player.bullet.vx + math.cos(2 * a) * player.bullet.vy
                player.bullet.pilIm = rotate(player.bullet.pilIm, 2 * a)
                canvas.delete(player.bullet.id)
                player.bullet.Im = ImageTk.PhotoImage(player.bullet.pilIm)
                player.bullet.id = canvas.create_image(player.bullet.x, player.bullet.y, image=player.bullet.Im)
    root.after(1, lambda: cactus_collision(player))


def scene():
    global pilImage, image
    pilImage = Image.open("поле.png")
    image = ImageTk.PhotoImage(pilImage)
    canvas.create_image(334, 250, image=image)


def main():
    global calboy1, calboy2, pilImage1, image1, pilImage2, image2
    scene()
    calboy1 = Cowboy(100, 260, 5, "кулбой1.png")
    pilImage1 = calboy1.pilIm
    image1 = calboy1.Im
    calboy2 = Cowboy(560, 260, -5, "кулбой2.png")
    pilImage2 = calboy2.pilIm
    image2 = calboy2.Im
    cactuses_generation()
    root.bind('<Shift_R>', calboy2.fire)
    root.bind('<Shift_L>', calboy1.fire)
    cactus_collision(calboy1)
    cactus_collision(calboy2)
    duel(calboy1, calboy2)
    duel(calboy2, calboy1)

    anim()


main()
root.mainloop()
